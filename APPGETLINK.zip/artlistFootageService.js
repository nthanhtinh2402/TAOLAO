const puppeteer = require('puppeteer');
const axios = require('axios');
const fs = require('fs-extra');
const { Parser } = require('m3u8-parser');
const path = require('path');

const videoPageUrl = 'https://artlist.io/stock-footage/clip/nepal-walking-horse-herd/6057976';

async function main() {
  const browser = await puppeteer.launch({ headless: false }); // mở browser để thấy luôn
  const page = await browser.newPage();

  let m3u8Url = '';

  page.on('request', (request) => {
    const url = request.url();
    if (url.includes('.m3u8') && !m3u8Url) {
      console.log('🔗 M3U8 URL:', url);
      m3u8Url = url;
    }
  });

  console.log('👉 Đang mở trang video...');
  await page.goto(videoPageUrl, { waitUntil: 'networkidle2' });

  console.log('⏳ Chờ bắt link m3u8...');
  await page.waitForTimeout(10000); // đợi người dùng tự bấm play hoặc chờ video tự load

  if (!m3u8Url) {
    console.error('❌ Không tìm thấy link .m3u8');
    await browser.close();
    return;
  }

  await browser.close();

  // Bước 2: Download file m3u8
  const m3u8Response = await axios.get(m3u8Url);
  const parser = new Parser();
  parser.push(m3u8Response.data);
  parser.end();

  const segments = parser.manifest.segments;
  if (!segments || segments.length === 0) {
    console.error('❌ Không tìm thấy phân đoạn .ts');
    return;
  }

  const baseUrl = m3u8Url.split('/').slice(0, -1).join('/');

  // --- Sửa ở đây: lưu trong downloads/artlist ---
  const videoFolder = path.join(__dirname, 'downloads', 'artlist');
  await fs.ensureDir(videoFolder);

  console.log(`📥 Bắt đầu tải ${segments.length} đoạn video...`);

  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i];
    const segmentUrl = `${baseUrl}/${segment.uri}`;

    const segmentPath = path.join(videoFolder, `${i.toString().padStart(4, '0')}.ts`);

    const response = await axios.get(segmentUrl, { responseType: 'arraybuffer' });
    await fs.writeFile(segmentPath, response.data);

    console.log(`✅ Tải xong đoạn ${i + 1}/${segments.length}`);
  }

  console.log('🎉 Tải xong toàn bộ file .ts tại downloads/artlist/');
  console.log('👉 Bạn có thể dùng ffmpeg để nối các file .ts lại thành 1 video hoàn chỉnh.');
}

main().catch(console.error);
