import fs from 'fs';
import path from 'path';
import { google } from 'googleapis';

export class GoogleDrive {
  constructor() {
    this.drive = null;
  }

  // Hàm khởi tạo Google Drive API và OAuth2 client
  async init() {
    const credentialsPath = path.resolve('./cookies/credentials.json');

    // Kiểm tra xem file credentials có tồn tại hay không
    if (!fs.existsSync(credentialsPath)) {
      console.error('Không tìm thấy file credentials.json');
      return;
    }

    const credentials = JSON.parse(fs.readFileSync(credentialsPath));

    const { client_secret, client_id, redirect_uris } = credentials.web;
    
    // Kiểm tra redirect_uris
    if (!redirect_uris || redirect_uris.length === 0) {
      console.error('Redirect URIs không được tìm thấy hoặc rỗng trong credentials.json');
      return;
    }
    
    const oAuth2Client = new google.auth.OAuth2(client_id, client_secret, redirect_uris[0]);

    // Kiểm tra token đã được lưu trong file `token.json`
    const tokenPath = path.resolve('youtube/utils/token.json');
    if (!fs.existsSync(tokenPath)) {
      console.log('Không tìm thấy token, vui lòng xác thực lại.');
      return;
    }

    try {
      const token = fs.readFileSync(tokenPath);
      oAuth2Client.setCredentials(JSON.parse(token));
    } catch (err) {
      console.error('Lỗi khi đọc file token:', err);
      return;
    }

    // Khởi tạo Google Drive API với OAuth2 client đã có
    this.drive = google.drive({ version: 'v3', auth: oAuth2Client });
    console.log('Google Drive API đã được khởi tạo thành công');
  }

  // Hàm upload file lên Google Drive
  async upload(filePath, fileName) {
    if (!this.drive) {
      console.log('Chưa khởi tạo Google Drive API, khởi tạo lại...');
      await this.init();
    }

    if (!this.drive) {
      console.error('Không thể khởi tạo Google Drive API.');
      return;
    }

    // Kiểm tra nếu file không tồn tại
    if (!fs.existsSync(filePath)) {
      console.error(`File không tồn tại: ${filePath}`);
      return;
    }

    const fileMetadata = {
      name: fileName,
      mimeType: 'video/x-matroska',  // Định dạng MKV
    };
    const media = {
      mimeType: 'video/x-matroska',
      body: fs.createReadStream(filePath),
    };

    return new Promise((resolve, reject) => {
      this.drive.files.create(
        {
          resource: fileMetadata,
          media: media,
          fields: 'id',
        },
        (err, file) => {
          if (err) {
            console.error('Lỗi khi tải lên Google Drive:', err);
            reject('Upload thất bại');
          } else {
            console.log(`Tải lên thành công: ${file.data.id}`);
            resolve(`https://drive.google.com/file/d/${file.data.id}/view`);
          }
        }
      );
    });
  }
}
