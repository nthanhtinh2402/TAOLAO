import youtubeService from '../services/youtubeService.js';

export default {
  handleDownloadRequest: async (req, res) => {
    try {
      const result = await youtubeService.getDownloadLink(req.query.url);
      if (result.success) {
        return res.json(result.data);
      }
      return res.status(400).json(result);
    } catch (error) {
      console.error('🔥 Lỗi controller:', error);
      return res.status(500).json({
        success: false,
        error: 'Lỗi hệ thống'
      });
    }
  }
};