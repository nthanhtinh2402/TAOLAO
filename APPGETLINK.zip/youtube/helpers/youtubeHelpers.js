export const validateYouTubeURL = (url) => {
  const patterns = [
    /^(https?:\/\/)?(www\.)?youtube\.com\/watch\?v=([a-zA-Z0-9_-]{11})/,
    /^(https?:\/\/)?youtu\.be\/([a-zA-Z0-9_-]{11})/
  ];
  return patterns.some(pattern => pattern.test(url));
};

export const extractVideoId = (url) => {
  const match = url.match(/(?:v=|\/)([a-zA-Z0-9_-]{11})/);
  return match ? match[1] : null;
};