import { execa } from 'execa';
import fs from 'fs/promises';
import path from 'path';
import youtubeConfig from '../config/youtubeConfig.js';
import { extractVideoId } from '../helpers/youtubeHelpers.js';
import { GoogleDrive } from '../utils/googleDrive.js';
import { getDomainInfo } from '../utils/getDomainInfo.js';

const drive = new GoogleDrive(youtubeConfig.drive);

const youtubeService = {
  getDownloadLink: async (url, req) => {
    const videoId = extractVideoId(url);
    const youtubeDir = path.join(youtubeConfig.paths.downloads || '', 'youtube');
    const cacheDir = path.join(youtubeConfig.paths.cache || '', 'youtube');
    const cachePath = path.join(cacheDir, `${videoId}.json`);
    const mergedFile = `blashee_getlink_${videoId}.mkv`;
    const mergedPath = path.join(youtubeDir, mergedFile);

    await fs.mkdir(youtubeDir, { recursive: true });
    await fs.mkdir(cacheDir, { recursive: true });

    let hostname = youtubeConfig.serverHost || '';
    if (req) {
      try {
        const { protocol, host } = getDomainInfo(req);
        hostname = protocol && host ? `${protocol}://${host}` : hostname;
      } catch {
        console.warn('[WARN] Không lấy được hostname từ request.');
      }
    }
    if (!hostname) {
      console.warn('[WARN] hostname trống, mặc định http://localhost:3000');
      hostname = 'http://localhost:3000';
    }

    const cookiesDir = path.join(youtubeConfig.paths.cookies || '', 'cookies');
    let cookiesFiles = await fs.readdir(cookiesDir);

    if (cookiesFiles.length === 0) {
      throw new Error('Không có cookies hợp lệ.');
    }

    // Dùng cookies ngẫu nhiên từ thư mục cookies
    const cookiesFilePath = path.join(cookiesDir, cookiesFiles[Math.floor(Math.random() * cookiesFiles.length)]);
    let cookiesContent = '';
    try {
      cookiesContent = await fs.readFile(cookiesFilePath, 'utf-8');
    } catch (error) {
      console.error('[ERROR] Không thể đọc file cookies:', error);
      throw new Error('Không thể đọc file cookies.');
    }

    try {
      const cachedData = await fs.readFile(cachePath, 'utf-8');
      const parsed = JSON.parse(cachedData);

      try {
        await fs.access(mergedPath);
      } catch {
        console.log('[INFO] File MKV chưa có, tiến hành merge lại ngầm...');
        execa('yt-dlp', [
          '-f', 'bestvideo+bestaudio',
          '--merge-output-format', 'mkv',
          '--concurrent-fragments', '4',
          '--no-check-certificate',
          '--cookies', cookiesFilePath,
          '-o', mergedPath,
          url
        ]).catch(error => console.error('[ERROR] Merge ngầm thất bại:', error));
      }

      console.log('[CACHE] Trả về từ cache.');
      return { ...parsed, downloadUrl: `${hostname}/downloads/youtube/${mergedFile}` };
    } catch {
      console.log('[INFO] Không có cache, bắt đầu tải mới...');
    }

    try {
      const { stdout } = await execa('yt-dlp', [
        '--dump-json',
        '--write-thumbnail',
        '--socket-timeout', '15',
        '--concurrent-fragments', '4',
        '--no-check-certificate',
        '--cookies', cookiesFilePath,
        '-o', `${youtubeConfig.paths.downloads}/%(title)s.%(ext)s`,
        url
      ]);

      const videoInfo = JSON.parse(stdout);

      const bestVideo = videoInfo.formats
        .filter(f => f.vcodec !== 'none' && f.acodec === 'none')
        .sort((a, b) => (b.height || 0) - (a.height || 0))[0];

      const bestAudio = videoInfo.formats
        .filter(f => f.acodec !== 'none' && f.vcodec === 'none')
        .sort((a, b) => (b.abr || 0) - (a.abr || 0))[0];

      if (!bestVideo || !bestAudio) {
        throw new Error('Không tìm thấy video hoặc audio phù hợp.');
      }

      console.log('[INFO] Đang merge video + audio thành MKV...');
      await execa('yt-dlp', [
        '-f', `${bestVideo.format_id}+${bestAudio.format_id}`,
        '--merge-output-format', 'mkv',
        '--concurrent-fragments', '4',
        '--no-check-certificate',
        '--cookies', cookiesFilePath,
        '-o', mergedPath,
        url
      ]);
      console.log('[INFO] Merge hoàn tất.');

      let driveUrl = '';
      if (youtubeConfig.drive.enabled) {
        driveUrl = await drive.upload(mergedPath, mergedFile);
      }

      const result = {
        id: videoId,
        title: videoInfo.title,
        downloadUrl: `${hostname}/downloads/youtube/${mergedFile}`,
        thumbnail: videoInfo.thumbnail,
        driveUrl,
        expiresAt: Date.now() + youtubeConfig.timing.autoDelete,
        formats: videoInfo.formats.map(f => ({
          format_id: f.format_id,
          quality: f.quality_label || `${f.height || 'unknown'}p`,
          ext: f.ext,
          vcodec: f.vcodec,
          acodec: f.acodec,
          filesize: f.filesize,
          url: f.url
        }))
      };

      await fs.writeFile(cachePath, JSON.stringify(result), 'utf-8');
      return result;
    } catch (error) {
      console.error('❌ Lỗi xử lý:', error);
      throw new Error(`Đã xảy ra lỗi khi xử lý video: ${error.message}`);
    }
  },

  cleanup: async () => {
    try {
      const now = Date.now();
      const youtubeDir = path.join(youtubeConfig.paths.downloads, 'youtube');

      const youtubeFiles = await fs.readdir(youtubeDir);
      for (const file of youtubeFiles) {
        const filePath = path.join(youtubeDir, file);
        const stats = await fs.stat(filePath);

        if (
          path.extname(file) === '.mkv' &&
          now - stats.birthtimeMs > youtubeConfig.timing.autoDelete
        ) {
          await fs.rm(filePath);
          console.log(`🧹 Đã xóa file video: ${file}`);
        }
      }
    } catch (error) {
      console.error('❌ Lỗi cleanup:', error.message);
    }
  }
};

// Tự động dọn dẹp mỗi 1 phút
setInterval(() => {
  youtubeService.cleanup();
}, 60 * 1000);

export default youtubeService;
