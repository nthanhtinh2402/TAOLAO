import puppeteer from 'puppeteer-extra';
import { loginIfNeeded, clickAndDownload } from '../helpers/envatoHelpers.js';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';

puppeteer.use(StealthPlugin());

export const getDownloadLink = async (productUrl) => {
  const browser = await puppeteer.launch({ headless: true });
  const page = await browser.newPage();
  await loginIfNeeded(page);  // Đảm bảo đã đăng nhập vào Envato
  await page.goto(productUrl);

  const downloadLink = await clickAndDownload(page);
  await browser.close();
  
  return downloadLink;
};
