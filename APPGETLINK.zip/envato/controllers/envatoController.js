import { getDownloadLink } from '../services/envatoService.js';

export const getEnvatoDownloadLink = async (req, res) => {
  const productUrl = req.query.url;
  if (!productUrl) {
    return res.status(400).send('❌ Missing ?url parameter');
  }

  try {
    const downloadLink = await getDownloadLink(productUrl);
    res.send(downloadLink);
  } catch (error) {
    res.status(500).send('❌ Error processing the Envato request');
  }
};
