import express from 'express';
import { getDownloadLink } from '../services/envatoService.js';

const router = express.Router();

router.get('/download', async (req, res) => {
  const url = req.query.url;
  try {
    const downloadLink = await getDownloadLink(url);
    res.json({ downloadLink });
  } catch (error) {
    res.status(500).json({ message: 'Error fetching download link from Envato' });
  }
});

export default router;
