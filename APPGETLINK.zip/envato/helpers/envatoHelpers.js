export const loginIfNeeded = async (page) => {
    // Logic login vào Envato nếu cần
  };
  
  export const clickAndDownload = async (page) => {
    // Logic tìm và nhấn nút tải xuống trên Envato
  };
  