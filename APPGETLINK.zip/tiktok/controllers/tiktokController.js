import { getDownloadLink } from '../services/tiktokService.js';

export const getTikTokDownloadLink = async (req, res) => {
  const tiktokUrl = req.query.url;
  if (!tiktokUrl) {
    return res.status(400).send('❌ Missing ?url parameter');
  }

  try {
    const downloadLink = await getDownloadLink(tiktokUrl);
    res.send(downloadLink);
  } catch (error) {
    res.status(500).send('❌ Error processing the TikTok request');
  }
};
