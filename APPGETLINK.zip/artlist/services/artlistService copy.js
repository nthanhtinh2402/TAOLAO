import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

puppeteer.use(StealthPlugin());

const cacheDir = path.join('cache', 'artlist');

function generateCacheFilename(url) {
  return crypto.createHash('md5').update(url).digest('hex') + '.json';
}

async function ensureCacheDir() {
  await fs.mkdir(cacheDir, { recursive: true });
}

async function readCache(cacheFile) {
  try {
    const data = await fs.readFile(cacheFile, 'utf-8');
    return JSON.parse(data)?.url || null;
  } catch {
    return null;
  }
}

async function saveCache(cacheFile, url) {
  await fs.writeFile(cacheFile, JSON.stringify({ url }), 'utf-8');
}

async function launchBrowser() {
  return puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-accelerated-2d-canvas',
      '--no-zygote',
      '--disable-software-rasterizer',
    ],
  });
}

export async function getDownloadLink(artlistUrl) {
  console.log(`[REQUEST] Nhận yêu cầu getlink cho: ${artlistUrl}`);

  await ensureCacheDir();
  const cacheFile = path.join(cacheDir, generateCacheFilename(artlistUrl));

  // Kiểm tra cache trước
  const cachedUrl = await readCache(cacheFile);
  if (cachedUrl) {
    console.log(`[CACHE] Đã tìm thấy cache, trả lại link: ${cachedUrl}`);
    return cachedUrl;
  }

  let browser;
  let page;

  try {
    browser = await launchBrowser();
    page = await browser.newPage();

    await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
    await page.setRequestInterception(true);

    let foundUrl = null;

    const downloadUrlPromise = new Promise((resolve) => {
      page.on('request', async (request) => {
        const url = request.url();
        if (!foundUrl && url.includes('.aac')) {
          foundUrl = url;
          console.log(`[FOUND] Tìm thấy link: ${url}`);
          await saveCache(cacheFile, url);
          resolve(url);
        }
        request.continue();
      });
    });

    await page.goto(artlistUrl, { waitUntil: 'networkidle2', timeout: 60000 });
    console.log(`[PAGE] Đã load trang: ${artlistUrl}`);

    await page.waitForSelector('button[aria-label="play global player"]', { timeout: 10000 });
    console.log(`[PAGE] Đã thấy nút play, click...`);

    await page.evaluate(() => {
      const playButton = document.querySelector('button[aria-label="play global player"]');
      if (playButton) playButton.click();
    });

    const result = await Promise.race([
      downloadUrlPromise,
      new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Không tìm thấy file .aac sau 10s')), 10000)
      ),
    ]);

    return result;

  } catch (err) {
    console.error(`[ERROR]`, err.message || err);
    return null; // Trả về null thay vì ném lỗi, để app không crash
  } finally {
    if (page && !page.isClosed()) {
      try { await page.close(); } catch (e) {}
    }
    if (browser) {
      try { await browser.close(); } catch (e) {}
    }
  }
}
