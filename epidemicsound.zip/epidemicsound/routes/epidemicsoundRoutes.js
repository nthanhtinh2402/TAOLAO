import express from 'express';
import epidemicsoundService from '../services/epidemicsoundService.js';

const router = express.Router();

router.get('/', (req, res) => {
  res.send('EpidemicSound API is online.');
});

router.get('/getlink', async (req, res) => {
  const url = req.query.url;
  if (!url) return res.status(400).json({ error: 'Thiếu URL' });

  try {
    const result = await epidemicsoundService.getDownloadLink(url);
    res.json({ downloadLink: result });
  } catch (err) {
    console.error('[EpidemicSound ERROR]', err);
    res.status(500).json({ error: err.message || 'Lỗi không xác định' });
  }
});

export default router;
