import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import fs from 'fs/promises';
import path from 'path';
import crypto from 'crypto';

puppeteer.use(StealthPlugin());

const cacheDir = path.join('cache', 'epidemicsound');

function generateCacheFilename(url) {
  return crypto.createHash('md5').update(url).digest('hex') + '.json';
}

async function ensureCacheDir() {
  await fs.mkdir(cacheDir, { recursive: true });
}

async function readCache(cacheFile) {
  try {
    const data = await fs.readFile(cacheFile, 'utf-8');
    return JSON.parse(data)?.url || null;
  } catch {
    return null;
  }
}

async function saveCache(cacheFile, url) {
  await fs.writeFile(cacheFile, JSON.stringify({ url }), 'utf-8');
}

async function launchBrowser() {
  return puppeteer.launch({
    headless: 'new',
    args: [
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--disable-dev-shm-usage',
      '--disable-gpu',
      '--disable-accelerated-2d-canvas',
      '--no-zygote',
      '--disable-software-rasterizer',
    ],
  });
}

const epidemicsoundService = {
  async getDownloadLink(epidemicUrl) {
    console.log(`[REQUEST] Nhận yêu cầu getlink cho: ${epidemicUrl}`);

    await ensureCacheDir();
    const cacheFile = path.join(cacheDir, generateCacheFilename(epidemicUrl));

    // Kiểm tra cache trước
    const cachedUrl = await readCache(cacheFile);
    if (cachedUrl) {
      console.log(`[CACHE] Đã tìm thấy cache, trả lại link: ${cachedUrl}`);
      return cachedUrl;
    }

    let browser;
    let page;

    try {
      browser = await launchBrowser();
      page = await browser.newPage();

      await page.setViewport({ width: 390, height: 844, isMobile: true, hasTouch: true });
      await page.setRequestInterception(true);

      let foundUrl = null;

      const downloadUrlPromise = new Promise((resolve) => {
        page.on('request', async (request) => {
          const url = request.url();
          if (!foundUrl && url.includes('.mp3')) { // Epidemic Sound thường dùng .mp3
            foundUrl = url;
            console.log(`[FOUND] Tìm thấy link: ${url}`);
            await saveCache(cacheFile, url);
            resolve(url);
          }
          request.continue();
        });
      });

      await page.goto(epidemicUrl, { waitUntil: 'networkidle2', timeout: 60000 });
      console.log(`[PAGE] Đã load trang: ${epidemicUrl}`);

      // Điều chỉnh selector phù hợp với nút "Play" hoặc "Download"
      await page.waitForSelector('button[aria-label="Play"]', { timeout: 10000 });
      console.log(`[PAGE] Đã thấy nút Play, đang click...`);

      await page.evaluate(() => {
        const playBtn = document.querySelector('button[aria-label="Play"]');
        if (playBtn) playBtn.click();
      });

      const result = await Promise.race([
        downloadUrlPromise,
        new Promise((_, reject) =>
          setTimeout(() => reject(new Error('Không tìm thấy file .mp3 sau 10s')), 10000)
        ),
      ]);

      return result;

    } catch (err) {
      console.error(`[ERROR]`, err.message || err);
      return null;
    } finally {
      if (page && !page.isClosed()) {
        try { await page.close(); } catch (e) {}
      }
      if (browser) {
        try { await browser.close(); } catch (e) {}
      }
    }
  }
};

export default epidemicsoundService;
