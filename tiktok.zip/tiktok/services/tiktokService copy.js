import { exec } from 'child_process';
import fs from 'fs/promises';
import path from 'path';
import { fileURLToPath } from 'url';
import { scheduleJob } from 'node-schedule';

// Cấu hình hệ thống
const CONFIG = {
  CACHE_TTL: 120000, // 2 phút
  RETRY_DELAY: 30000, // 30 giây
  MAX_RETRY: 3,
  TEMP_PREFIX: 'temp_'
};

// Khởi tạo đường dẫn
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const appDir = process.cwd();
const directories = {
  downloads: path.join(appDir, 'downloads', 'tiktok'),
  cache: path.join(appDir, 'cache', 'tiktok')
};

// Khởi tạo thư mục
const initDirectories = async () => {
  await Promise.all(
    Object.values(directories).map(dir =>
      fs.mkdir(dir, { recursive: true })
    )
  );
};

// Quản lý job xóa file
const deletionManager = {
  jobs: new Map(),

  schedule(filePath, delay = CONFIG.CACHE_TTL) {
    const job = scheduleJob(new Date(Date.now() + delay), async () => {
      try {
        await fs.access(filePath);
        await fs.unlink(filePath);
       
        console.log(`✅ Đã xóa file: ${path.basename(filePath)}`);
      } catch (error) {
        this.handleDeletionError(error, filePath);
      } finally {
        this.jobs.delete(filePath);
      }
    });

    this.jobs.set(filePath, job);
  },

  async cleanCache(filePath) {
    try {
      const videoId = path.basename(filePath, '.mp4').split('_').pop();
      const cachePath = path.join(directories.cache, `${videoId}.json`);
      await fs.unlink(cachePath);
    } catch (error) {
      console.error('⚠️ Lỗi xóa cache:', error.message);
    }
  },

  handleDeletionError(error, filePath, retryCount = 0) {
    const filename = path.basename(filePath);

    if (error.code === 'EBUSY' && retryCount < CONFIG.MAX_RETRY) {
      console.log(`🔄 Thử lại xóa ${filename} (lần ${retryCount + 1})`);
      setTimeout(() => this.schedule(filePath, CONFIG.RETRY_DELAY), retryCount + 1);
      return;
    }

    console.error(`❌ Lỗi xóa ${filename}:`, error.message);
  }
};

// Xử lý video
const videoProcessor = {
  getMetadata: (url) => new Promise((resolve, reject) => {
    exec(`yt-dlp -j ${url}`, (error, stdout) => {
      if (error) return reject(new Error('METADATA_FETCH_FAILED'));
      try {
        resolve(JSON.parse(stdout));
      } catch {
        reject(new Error('INVALID_METADATA'));
      }
    });
  }),

  downloadVideo: async (url, videoId) => {
    const tempPrefix = `${CONFIG.TEMP_PREFIX}${videoId}`;
    const finalFile = path.join(directories.downloads, `blashee_getlink_${videoId}.mp4`);

    await new Promise((resolve, reject) => {
      const command = `yt-dlp -o "${path.join(directories.downloads, tempPrefix)}.%(ext)s" ${url}`;
      exec(command, async (error) => {
        if (error) return reject(new Error('DOWNLOAD_FAILED'));

        try {
          const files = await fs.readdir(directories.downloads);
          const downloadedFile = files.find(f => f.startsWith(tempPrefix));

          if (!downloadedFile) throw new Error('FILE_NOT_FOUND');

          await fs.rename(
            path.join(directories.downloads, downloadedFile),
            finalFile
          );
          resolve();
        } catch (renameError) {
          console.error('[DEBUG] Rename failed:', renameError);
          reject(new Error('FILE_PROCESSING_ERROR'));
        }
      });
    });

    return finalFile;
  }
};

// Quản lý cache
const cacheService = {
  read: async (videoId) => {
    try {
      const cachePath = path.join(directories.cache, `${videoId}.json`);
      const data = JSON.parse(await fs.readFile(cachePath, 'utf-8'));

      if (new Date(data.expiresAt) < new Date()) {
        await fs.unlink(cachePath);
        return null;
      }

      return data;
    } catch {
      return null;
    }
  },

  write: async (videoId, data) => {
    const cachePath = path.join(directories.cache, `${videoId}.json`);
    await fs.writeFile(cachePath, JSON.stringify({
      ...data,
      expiresAt: new Date(Date.now() + CONFIG.CACHE_TTL)
    }, null, 2));
  }
};

// Service chính
export const getDownloadLink = async (tiktokUrl, baseUrl) => {
  await initDirectories();

  try {
    const videoId = sanitizeFilename(tiktokUrl.split('/').pop());
    const fileName = `blashee_getlink_${videoId}.mp4`;
    const filePath = path.join(directories.downloads, fileName);

    // Kiểm tra cache
    const cached = await cacheService.read(videoId);
    if (cached && await fileExists(filePath)) {
      console.log(`⚡ Trả kết quả từ cache: ${videoId}`);
      return formatResponse(fileName, baseUrl, cached);
    }

    // Tải mới
    const { title, thumbnail } = await videoProcessor.getMetadata(tiktokUrl);
    const finalPath = await videoProcessor.downloadVideo(tiktokUrl, videoId);

    await cacheService.write(videoId, { title, thumbnail });
    deletionManager.schedule(finalPath);

    return formatResponse(fileName, baseUrl, { title, thumbnail });
  } catch (error) {
    handleError(error);
  }
};

// Hàm hỗ trợ
const sanitizeFilename = (name) => name.replace(/[^a-zA-Z0-9_-]/g, '');
const fileExists = async (path) => fs.access(path).then(() => true).catch(() => false);
const formatResponse = (fileName, baseUrl, { title, thumbnail }) => ({
  fileName,
  videoLink: `${baseUrl}/downloads/tiktok/${fileName}`,
  title,
  thumbnail
});

const errorMessages = {
  METADATA_FETCH_FAILED: 'Không thể lấy thông tin video',
  INVALID_METADATA: 'Dữ liệu video không hợp lệ',
  DOWNLOAD_FAILED: 'Tải video thất bại',
  FILE_NOT_FOUND: 'Không tìm thấy file tải về',
  FILE_PROCESSING_ERROR: 'Lỗi xử lý file'
};

const handleError = (error) => {
  const message = errorMessages[error.message] || 'Lỗi hệ thống';
  throw new Error(`${message} (${error.message})`);
};

export const service = { getDownloadLink };
