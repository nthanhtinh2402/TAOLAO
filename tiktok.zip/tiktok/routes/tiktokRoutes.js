import express from 'express';

import { getDownloadLink } from '../services/tiktokService.js';

const router = express.Router();

router.get('/download', async (req, res) => {
  const url = req.query.url;

  if (!url || !url.includes('tiktok.com')) {
    return res.status(400).json({ error: 'Thiếu hoặc sai định dạng link TikTok' });
  }

  try {
    const baseUrl = req.protocol + '://' + req.get('host');
    const { fileName, title, thumbnail, videoLink } = await service.getDownloadLink(url, baseUrl);

    res.json({ success: true, title, thumbnail, videoLink });
  } catch (error) {
    console.error('[TikTok ERROR]', error.message);
    res.status(500).json({ message: 'Error fetching download link from TikTok' });
  }
});

export default router;
