export const getTikTokDownloadLinkFromPage = async (page) => {
    // Logic lấy link tải xuống video TikTok
    // Ví dụ: Trích xuất link video từ DOM của trang TikTok
  };
  