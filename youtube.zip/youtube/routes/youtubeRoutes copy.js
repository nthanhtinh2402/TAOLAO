import express from 'express';
import youtubeService from '../services/youtubeService.js';
import path from 'path';
import fs from 'fs/promises';

const router = express.Router();

// Route để xử lý lấy link tải
router.get('/api.youtube/download/:videoId', async (req, res) => {
  try {
    const videoId = req.params.videoId;
    const url = `https://www.youtube.com/watch?v=${videoId}`;
    const result = await youtubeService.getDownloadLink(url, req); // ✅ Truyền req vào

    res.json(result);
  } catch (error) {
    console.error('❌ Lỗi tại /api.youtube/download:', error);
    res.status(500).json({ error: error.message });
  }
});

// Route để phục vụ file MKV trực tiếp
router.get('/downloads/youtube/:filename', async (req, res) => {
  const filename = req.params.filename;
  const filePath = path.resolve('downloads/youtube', filename);

  try {
    await fs.access(filePath);
    res.download(filePath);
  } catch (error) {
    console.error('❌ Không tìm thấy file:', filePath);
    res.status(404).send('File not found');
  }
});

export default router;
