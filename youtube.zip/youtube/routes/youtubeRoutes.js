import express from 'express';
import youtubeService from '../services/youtubeService.js';
import path from 'path';
import fs from 'fs/promises';

const router = express.Router();

// Helper function để xử lý duration
const formatDuration = (seconds) => {
  if (!seconds || isNaN(seconds)) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

// Route xử lý lấy thông tin video
router.get('/api.youtube/download/:videoId', async (req, res) => {
  let responseSent = false;
  
  try {
    const videoId = req.params.videoId;
    
    // Validate video ID chặt chẽ hơn
    if (!videoId || !/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
      if (!responseSent) {
        responseSent = true;
        return res.status(400).json({
          success: false,
          error: 'Invalid YouTube video ID format',
          code: 'INVALID_VIDEO_ID'
        });
      }
    }

    const url = `https://www.youtube.com/watch?v=${videoId}`;
    const videoInfo = await youtubeService.getVideoInfo(url);

    // Kiểm tra dữ liệu trả về từ service
    if (!videoInfo?.formats || !Array.isArray(videoInfo.formats)) {
      throw new Error('Invalid video info response from service');
    }

    // Tạo response object an toàn
    const safeResponse = {
      success: true,
      data: {
        id: videoId,
        title: videoInfo.title || 'No title',
        duration: formatDuration(videoInfo.duration),
        thumbnail: videoInfo.thumbnail || '',
        formats: videoInfo.formats
          .filter(format => format.url) // Lọc các format không có URL
          .map(format => ({
            itag: format.itag,
            quality: format.qualityLabel || format.quality || 'unknown',
            type: format.hasVideo ? 'Video' : 'Audio',
            container: format.container || '',
            url: format.url
          }))
      }
    };

    if (!responseSent) {
      responseSent = true;
      return res.json(safeResponse);
    }

  } catch (error) {
    console.error('❌ [Route Error] /api.youtube/download:', error);
    
    if (!responseSent) {
      responseSent = true;
      return res.status(500).json({
        success: false,
        error: 'Video processing failed',
        code: 'PROCESSING_ERROR',
        details: error.message
      });
    }
  }
});

// Route download file
router.get('/downloads/youtube/:filename', async (req, res) => {
  let headersSent = false;
  let fileStream = null;

  try {
    const filename = path.basename(req.params.filename); // Chống directory traversal
    const filePath = path.resolve('downloads/youtube', filename);

    // Kiểm tra file tồn tại
    await fs.access(filePath);
    const stats = await fs.stat(filePath);

    // Thiết lập headers
    if (!headersSent) {
      headersSent = true;
      res.setHeader('Content-Type', 'application/octet-stream');
      res.setHeader('Content-Length', stats.size);
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(filename)}"`);
    }

    // Xử lý stream
    fileStream = fs.createReadStream(filePath);
    
    // Xử lý sự kiện client disconnect
    req.on('close', () => {
      if (fileStream) {
        fileStream.destroy();
      }
    });

    // Xử lý lỗi stream
    fileStream.on('error', (error) => {
      console.error('🚨 Stream Error:', error);
      if (!headersSent) {
        headersSent = true;
        res.status(500).json({
          success: false,
          error: 'File stream error',
          code: 'STREAM_ERROR'
        });
      }
    });

    // Pipe response
    fileStream.pipe(res);

  } catch (error) {
    console.error('❌ [Download Error]:', error.message);
    
    if (!headersSent) {
      headersSent = true;
      return res.status(404).json({
        success: false,
        error: 'File not found',
        code: 'FILE_NOT_FOUND'
      });
    }
  }
});

export default router;