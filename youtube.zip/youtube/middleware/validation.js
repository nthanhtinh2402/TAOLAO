export const validateYouTubeRequest = (req, res, next) => {
    const { videoId } = req.params;
    
    if (!/^[a-zA-Z0-9_-]{11}$/.test(videoId)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid YouTube video ID',
        code: 'INVALID_VIDEO_ID'
      });
    }
    
    next();
  };