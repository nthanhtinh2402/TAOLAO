import path from 'path';
import fs from 'fs/promises';

const youtubeConfig = {
  api: {
    endpoint: 'http://localhost:3000/api.youtube' // URL API cố định
  },
  timing: {
    autoDelete: 2 * 60 * 1000 // 🕒 2 phút
  },
  drive: {
    enabled: false,
    client_id: '817907544016-2i7bsfdenpsb85bgov475jfoji262p2d.apps.googleusercontent.com',
    client_secret: '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',
    redirect_uri: 'http://localhost:3000/oauth2callback'
  },
  paths: {
    downloads: path.resolve('downloads'),
    cache: path.resolve('cache'),
    cookies: path.resolve('cookies') // 👉 Thư mục chứa file cookies
  },
  serverHost: 'http://localhost:3000' // 👉 Hostname của server để tạo link tuyệt đối
};

const createDirs = async () => {
  try {
    await fs.mkdir(youtubeConfig.paths.downloads, { recursive: true });
    await fs.mkdir(youtubeConfig.paths.cache, { recursive: true });
    await fs.mkdir(youtubeConfig.paths.cookies, { recursive: true });
    console.log('[INFO] Thư mục downloads, cache và cookies đã được tạo.');
  } catch (error) {
    console.error('[ERROR] Không thể tạo thư mục:', error.message);
  }
};

createDirs();

export default youtubeConfig;
