// File: youtube/config/youtubeConfig.js

import path from 'path';
import fs from 'fs/promises'; // Thêm fs để tạo thư mục nếu chưa tồn tại

const youtubeConfig = {
  api: {
    endpoint: 'http://localhost:3000/api.youtube' // Địa chỉ API không dùng .env
  },
  timing: {
    autoDelete: 2 * 60 * 1000, // 🕒 2 phút
  },
  drive: {
    enabled: false, // Bật Google Drive
    client_id: '817907544016-2i7bsfdenpsb85bgov475jfoji262p2d.apps.googleusercontent.com', // Client ID của bạn từ Google API
    client_secret: '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', // Client Secret của bạn
    redirect_uri: 'http://localhost:3000/oauth2callback' // Redirect URI của bạn
  },
  paths: {
    // Sử dụng đường dẫn tuyệt đối và tạo thư mục nếu chưa tồn tại
    downloads: path.resolve('downloads'),
    cache: path.resolve('cache')
  }
};

// Tạo thư mục nếu chưa tồn tại
const createDirs = async () => {
  try {
    await fs.mkdir(youtubeConfig.paths.downloads, { recursive: true });
    await fs.mkdir(youtubeConfig.paths.cache, { recursive: true });
    console.log('[INFO] Thư mục downloads và cache đã được tạo.');
  } catch (error) {
    console.error('[ERROR] Không thể tạo thư mục:', error);
  }
};

createDirs(); // Gọi hàm tạo thư mục

export default youtubeConfig;
