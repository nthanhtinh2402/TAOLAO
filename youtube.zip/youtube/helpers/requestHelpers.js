export function getRequestHost(req) {
    // Kiểm tra xem req và req.headers có tồn tại hay không
    if (!req || !req.headers) {
      throw new Error("Không có headers trong yêu cầu.");
    }
  
    const proto = req.headers['x-forwarded-proto'] || req.protocol || 'http';
    const host = req.headers['host'] || 'localhost:3000';
    
    return `${proto}://${host}`;
  }
  