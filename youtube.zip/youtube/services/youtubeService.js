import { execa } from 'execa';
import fs from 'fs/promises';
import path from 'path';
import youtubeConfig from '../config/youtubeConfig.js';
import { extractVideoId } from '../helpers/youtubeHelpers.js';
import { GoogleDrive } from '../utils/googleDrive.js';
import { getRequestHost } from '../helpers/requestHelpers.js';

const drive = new GoogleDrive(youtubeConfig.drive);

const sanitizeFormatData = (formats) => {
  return formats.map(format => ({
    itag: format.itag,
    url: format.url,
    quality: format.qualityLabel || `${format.height}p` || 'unknown',
    mimeType: format.mimeType?.split(';')[0] || null,
    container: format.container,
    codec: format.codecs || null,
    contentLength: format.contentLength,
    hasVideo: format.hasVideo,
    hasAudio: format.hasAudio
  })).filter(f => f.url);
};

const youtubeService = {
  getDownloadLink: async (url, req) => {
    try {
      const videoId = extractVideoId(url);
      if (!videoId) throw new Error('Invalid YouTube URL');

      if (!req || !req.headers) throw new Error('Không có headers trong yêu cầu.');

      const hostname = getRequestHost(req) || youtubeConfig.serverHost;

      const youtubeDir = path.join(youtubeConfig.paths.downloads, 'youtube');
      const cacheDir = path.join(youtubeConfig.paths.cache, 'youtube');
      const cachePath = path.join(cacheDir, `${videoId}.json`);
      const mergedFile = `blashee_${videoId}.mkv`;
      const mergedPath = path.join(youtubeDir, mergedFile);

      await Promise.all([
        fs.mkdir(youtubeDir, { recursive: true }),
        fs.mkdir(cacheDir, { recursive: true })
      ]);

      const cookiesDir = path.join(youtubeConfig.paths.cookies, 'cookies');
      const cookiesFiles = await fs.readdir(cookiesDir);
      if (cookiesFiles.length === 0) throw new Error('No valid cookies');

      const cookiesFilePath = path.join(
        cookiesDir,
        cookiesFiles[Math.floor(Math.random() * cookiesFiles.length)]
      );

      // Kiểm tra cache
      try {
        const [cachedData, fileExists] = await Promise.all([
          fs.readFile(cachePath, 'utf-8'),
          fs.access(mergedPath).then(() => true).catch(() => false)
        ]);

        const parsed = JSON.parse(cachedData);
        if (!fileExists) {
          console.log('[BACKGROUND] Merging video...');
          execa('yt-dlp', [
            '-f', 'bestvideo+bestaudio',
            '--merge-output-format', 'mkv',
            '--concurrent-fragments', '4',
            '--no-check-certificates',
            '--cookies', cookiesFilePath,
            '-o', mergedPath,
            url
          ]).catch(console.error);
        }

        return {
          ...parsed,
          downloadUrl: `${hostname}/downloads/youtube/${mergedFile}`,
          formats: sanitizeFormatData(parsed.formats)
        };

      } catch (cacheError) {
        console.log('[INFO] Starting new download process...');
      }

      // Tải mới
      const { stdout } = await execa('yt-dlp', [
        '--dump-json',
        '--socket-timeout', '15',
        '--concurrent-fragments', '4',
        '--no-check-certificates',
        '--cookies', cookiesFilePath,
        '-o', path.join(youtubeConfig.paths.downloads, '%(title)s.%(ext)s'),
        url
      ]);

      const videoInfo = JSON.parse(stdout);

      // Tìm video (ưu tiên có video, không quan tâm audio)
      const [bestVideo] = videoInfo.formats
        .filter(f => f.vcodec !== 'none')
        .sort((a, b) => (b.height || 0) - (a.height || 0));

      // Tìm audio (ưu tiên có audio, không quan tâm video)
      const [bestAudio] = videoInfo.formats
        .filter(f => f.acodec !== 'none')
        .sort((a, b) => (b.abr || 0) - (a.abr || 0));

      if (!bestVideo || !bestAudio) {
        throw new Error('Không tìm thấy video/audio phù hợp');
      }

      console.log('[PROCESS] Merging streams...');
      await execa('yt-dlp', [
        '-f', `${bestVideo.format_id}+${bestAudio.format_id}`,
        '--merge-output-format', 'mkv',
        '--concurrent-fragments', '4',
        '--no-check-certificates',
        '--cookies', cookiesFilePath,
        '-o', mergedPath,
        url
      ]);

      let driveUrl = '';
      if (youtubeConfig.drive.enabled) {
        try {
          driveUrl = await drive.upload(mergedPath, mergedFile);
        } catch (driveError) {
          console.error('[DRIVE] Upload failed:', driveError);
        }
      }

      const result = {
        id: videoId,
        title: videoInfo.title,
        downloadUrl: `${hostname}/downloads/youtube/${mergedFile}`,
        thumbnail: videoInfo.thumbnail,
        driveUrl,
        expiresAt: Date.now() + youtubeConfig.timing.autoDelete,
        formats: sanitizeFormatData(videoInfo.formats)
      };

      await fs.writeFile(cachePath, JSON.stringify(result, null, 2));
      return result;

    } catch (error) {
      console.error('[SERVICE ERROR]', error);
      const err = new Error(error.message);
      err.code = error.code || 'YT_SERVICE_ERROR';
      throw err;
    }
  },

  cleanup: async () => {
    try {
      const now = Date.now();
      const youtubeDir = path.join(youtubeConfig.paths.downloads, 'youtube');
      const files = await fs.readdir(youtubeDir);

      await Promise.all(files.map(async (file) => {
        if (path.extname(file) !== '.mkv') return;

        const filePath = path.join(youtubeDir, file);
        const stats = await fs.stat(filePath);

        if (now - stats.birthtimeMs > youtubeConfig.timing.autoDelete) {
          await fs.rm(filePath);
          console.log(`[CLEANUP] Removed ${file}`);
        }
      }));
    } catch (error) {
      console.error('[CLEANUP ERROR]', error.message);
    }
  }
};

const CLEANUP_INTERVAL = 5 * 60 * 1000;
const cleanupInterval = setInterval(() => youtubeService.cleanup(), CLEANUP_INTERVAL);

process.on('SIGTERM', () => {
  clearInterval(cleanupInterval);
});

export default youtubeService;
