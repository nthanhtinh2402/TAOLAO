export const youtubeController = {
  handleDownloadRequest: async (req, res) => {
    let responseSent = false;
    try {
      const result = await youtubeService.getDownloadLink(req.query.url, req);
      
      if (!responseSent) {
        responseSent = true;
        return res.json({
          success: true,
          data: {
            ...result,
            formats: result.formats.map(f => ({
              // Lọc tiếp các trường nhạy cảm
              itag: f.itag,
              url: f.url,
              quality: f.quality,
              mimeType: f.mimeType
            }))
          }
        });
      }
    } catch (error) {
      console.error('🔥 Controller Error:', error);
      if (!responseSent) {
        responseSent = true;
        return res.status(error.code === 'YT_PROCESS_ERROR' ? 400 : 500).json({
          success: false,
          error: error.message,
          code: error.code
        });
      }
    }
  }
};
export default youtubeController;