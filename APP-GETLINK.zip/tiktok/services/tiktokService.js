import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Đảm bảo __dirname được khai báo chính xác khi dùng ES modules
const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Đảm bảo chúng ta lấy đúng thư mục gốc của ứng dụng (APP-GETLINK)
const appDir = process.cwd(); // Thư mục gốc của ứng dụng
const tiktokFolder = path.join(appDir, 'downloads', 'tiktok'); // Đường dẫn đến thư mục downloads/tiktok
const cacheFolder = path.join(appDir, 'cache', 'tiktok'); // Đường dẫn đến thư mục cache/tiktok

// Tạo thư mục tiktok trong downloads nếu chưa có
if (!fs.existsSync(tiktokFolder)) {
  fs.mkdirSync(tiktokFolder, { recursive: true });
}

// Tạo thư mục tiktok trong cache nếu chưa có
if (!fs.existsSync(cacheFolder)) {
  fs.mkdirSync(cacheFolder, { recursive: true });
}

// Hàm làm sạch tên file
function sanitizeFileName(fileName) {
  return fileName.replace(/[^a-zA-Z0-9_-]/g, '');
}

// Đọc tệp cache riêng biệt cho mỗi video (theo videoId)
function readCache(videoId) {
  const cacheFilePath = path.join(cacheFolder, `${videoId}.json`);
  if (fs.existsSync(cacheFilePath)) {
    const data = fs.readFileSync(cacheFilePath, 'utf-8');
    return JSON.parse(data);
  }
  return null;
}

// Ghi cache riêng biệt cho mỗi video (theo videoId)
function writeCache(videoId, data) {
  const cacheFilePath = path.join(cacheFolder, `${videoId}.json`);
  fs.writeFileSync(cacheFilePath, JSON.stringify(data, null, 2));
}

// Gói function vào 1 object rồi export đúng chuẩn app.js đang xài
const service = {
  getDownloadLink: async (tiktokUrl, baseUrl) => {
    return new Promise((resolve, reject) => {
      const videoId = tiktokUrl.split('/').pop();
      const sanitizedVideoId = sanitizeFileName(videoId);
      const fileName = `blashee_getlink_${sanitizedVideoId}.mp4`;
      const filePath = path.join(tiktokFolder, fileName); // Lưu vào thư mục downloads/tiktok trong thư mục gốc của dự án

      // Kiểm tra cache trước khi tải video
      const cachedVideo = readCache(sanitizedVideoId);

      if (cachedVideo) {
        // Nếu video đã có trong cache nhưng file không tồn tại, tải lại video
        if (!fs.existsSync(filePath)) {
          console.log(`⚠️ File video không còn, tải lại video: ${fileName}`);

          // Trả kết quả cho người dùng ngay với thông báo đang tải lại video
          const videoLink = `${baseUrl}/downloads/tiktok/${fileName}`;
          resolve({
            fileName,
            videoLink,
            title: cachedVideo.title, // Trả lại title từ cache
            thumbnail: cachedVideo.thumbnail, // Trả lại thumbnail từ cache
            status: 'Video đang được tải lại trong nền. Vui lòng đợi một lúc.'
          });

          // Sau khi trả kết quả cho người dùng, bắt đầu tải lại video trong nền
          exec(`yt-dlp -o "${filePath}" --merge-output-format mp4 ${tiktokUrl}`, (error, stdout, stderr) => {
            if (error || stderr) return console.error('❌ Không thể tải lại video.');

            // Cập nhật lại thông tin trong cache
            const videoCache = {
              videoId: sanitizedVideoId,
              fileName,
              title: cachedVideo.title,
              thumbnail: cachedVideo.thumbnail,
              dateAdded: new Date().toISOString(),
            };

            writeCache(sanitizedVideoId, videoCache); // Ghi lại vào tệp cache sau khi tải lại video
            console.log(`✅ Tải lại video thành công: ${fileName}`);
          });
        } else {
          // Nếu file đã tồn tại, trả về link và thông tin cache
          console.log(`✅ Video đã có trong cache: ${fileName}`);
          const videoLink = `${baseUrl}/downloads/tiktok/${fileName}`;
          resolve({
            fileName,
            videoLink,
            title: cachedVideo.title, // Trả lại title từ cache
            thumbnail: cachedVideo.thumbnail // Trả lại thumbnail từ cache
          });
        }
      } else {
        // Nếu không có cache, tải video từ TikTok
        exec(`yt-dlp -j ${tiktokUrl}`, (error, stdout, stderr) => {
          if (error || stderr) return reject(new Error('❌ Không thể lấy thông tin video.'));

          const info = JSON.parse(stdout);
          const title = info.title;
          const thumbnail = info.thumbnail;

          // Tải video và lưu vào thư mục tiktok
          exec(`yt-dlp -o "${filePath}" --merge-output-format mp4 ${tiktokUrl}`, (error, stdout, stderr) => {
            if (error || stderr) return reject(new Error('❌ Không thể tải video.'));

            // Thêm video vào cache sau khi tải xong
            const videoCache = {
              videoId: sanitizedVideoId,
              fileName,
              title,
              thumbnail,
              dateAdded: new Date().toISOString(),
            };

            writeCache(sanitizedVideoId, videoCache); // Ghi lại vào tệp cache riêng biệt

            // Tự động xoá file sau 2 phút
            setTimeout(() => {
              fs.unlink(filePath, (err) => {
                if (err) console.error(`⚠️ Không thể xoá file: ${err.message}`);
                else console.log(`🗑️ Đã xoá file sau 2 phút: ${filePath}`);
              });
            }, 120000); // 2 phút

            // Cấu hình video link trả về
            const videoLink = `${baseUrl}/downloads/tiktok/${fileName}`;

            resolve({ fileName, title, thumbnail, videoLink });
          });
        });
      }
    });
  }
};

// Export object service có chứa getDownloadLink
export { service };

// Xuất riêng getDownloadLink để app.js không cần đổi
export const getDownloadLink = service.getDownloadLink;
