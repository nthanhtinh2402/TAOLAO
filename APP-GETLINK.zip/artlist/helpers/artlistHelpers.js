export const getArtlistDownloadLinkFromPage = async (page) => {
    // Logic lấy link tải xuống từ Artlist
  };
  