import { getDownloadLink } from '../services/artlistService.js';

export const getArtlistDownloadLink = async (req, res) => {
  const artlistUrl = req.query.url;
  if (!artlistUrl) {
    return res.status(400).send('❌ Missing ?url parameter');
  }

  try {
    const downloadLink = await getDownloadLink(artlistUrl);
    res.send(downloadLink);
  } catch (error) {
    res.status(500).send('❌ Error processing the Artlist request');
  }
};
