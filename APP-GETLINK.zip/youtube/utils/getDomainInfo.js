export const getDomainInfo = (req) => {
    if (!req) return { protocol: 'http', host: 'localhost' };
  
    const protocol = req.protocol || (req.headers['x-forwarded-proto'] ? req.headers['x-forwarded-proto'].split(',')[0] : 'http');
    const host = req.get('host') || req.headers['host'] || 'localhost';
  
    return {
      protocol,
      host
    };
  };
  